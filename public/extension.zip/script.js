document.getElementById("forURL").addEventListener("click", getURL);
document.getElementById("forQR").addEventListener("click", generateQR);
document.getElementById("copybtn").addEventListener("click", myFunction);

async function getURL() {
    var url = document.getElementById("content");
    const regexp = new RegExp(/^(https?|chrome):\/\//, 'i');
    const regurl = new RegExp(/[^\s$.?#]+\..+/);
    var urlIp = url.value;
    if(!regexp.test(url.value)) {
        urlIp = 'http://' + url.value;
    }
    if(!regurl.test(urlIp)) {
        var msg = document.getElementById("message");
            msg.style.display = 'block';
            msg.innerHTML = 'url is invalid';
            setTimeout(()=>{
                msg.style.display = 'none';
            }, 5000)
    } else {
        const data = { queryUrl: urlIp };
        const response = await fetch("https://turu.vercel.app/urlapi", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data)
        });
        const result = await response.text();
        document.getElementById("shortened").style.display = "block";
        document.getElementById("copy").value = result;
    }
}

async function generateQR() {
    let data = document.getElementById("content").value;
    if (data) {
        const response = await fetch("https://turu.vercel.app/getqr", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({qrurl: data})
        })
        const result = await response.text();
        document.getElementById("qr").style.display = "block";
        document.getElementById("qrimg").src = result;
        document.getElementById("qrdownload").href = result;
    }
}

function myFunction() {
    var copyText = document.getElementById("copy");
    if(copyText.value) {
        copyText.select();
        copyText.setSelectionRange(0, 99999);  
        document.execCommand("copy");
        var msg = document.getElementById("message");
            msg.style.display = 'block';
            msg.innerHTML = "Copied: " + copyText.value;
            setTimeout(()=>{
                msg.style.display = 'none';
            }, 5000)
    }
}